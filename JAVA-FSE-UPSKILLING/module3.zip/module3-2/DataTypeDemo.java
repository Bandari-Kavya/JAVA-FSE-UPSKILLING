public class DataTypeDemo {
    public static void main(String[] args) {
        int myInt = 25;
        float myFloat = 12.5f;
        double myDouble = 123.456;
        char myChar = 'A';
        boolean myBoolean = true;

        System.out.println("Integer: " + myInt);
        System.out.println("Float: " + myFloat);
        System.out.println("Double: " + myDouble);
        System.out.println("Character: " + myChar);
        System.out.println("Boolean: " + myBoolean);
    }
}

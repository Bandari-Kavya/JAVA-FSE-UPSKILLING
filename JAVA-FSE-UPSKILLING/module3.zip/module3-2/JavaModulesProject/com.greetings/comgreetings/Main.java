package comgreetings;

import comutils.StringUtils;

public class Main {
    public static void main(String[] args) {
        String name = "john";
        System.out.println("Hello, " + StringUtils.upperCase(name) + "!");
    }
}
